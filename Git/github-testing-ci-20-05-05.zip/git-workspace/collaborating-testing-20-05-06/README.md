# collaborating-testing-20-05-06
Repository for the collab-testing workshop 2020 May 6th

Added line to README.md to demonstrate pushing to remote repository on github.

