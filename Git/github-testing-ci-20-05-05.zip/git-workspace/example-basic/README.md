ex-basic
========

This repository has just 5 basic commits on master by three different coders, providing a basic commit structure for learning exploring Git commands.

## Usage

* Using `git log` to review simple history
* Filtering `git log` with `--author` option

Added a new line to Readme to understand git diff

A second line to demonstrate git status for unstaged changes

A second exposition of chaging files, staging changes and committing them to repository
