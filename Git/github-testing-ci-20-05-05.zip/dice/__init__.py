from .dice import Dice
