ex-basic
========

This repository has just 5 basic commits on master by three different coders, providing a basic commit structure for learning exploring Git commands.

## Usage

* Using `git log` to review simple history
* Filtering `git log` with `--author` option

I modified the readme.

Added a crazy idea about parallel universes.

I disagree parallel universes are perfectly sensible

As we can see some still thinks that parallel universes are real.
