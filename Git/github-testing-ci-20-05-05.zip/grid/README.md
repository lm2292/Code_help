# CI Test

[![Build Status](https://travis-ci.org/USERNAME/grid.svg?branch=master)](https://travis-ci.org/USERNAME/grid)

## About
A repository to test continuous integration for the [Python and Data](http://chryswoods.com/python_and_data)
workshop at the University of Bristol, Dec 2017.
