# Github, Testing and Continuous Integration

James Grant, Research Software Engineer, rjg20@bath.ac.uk

This library contains notebooks for demonstrator and students for the [Github, Testing and CI](https://arc-lessons.github.io/github-testing-ci/00_schedule.html)  Lesson. The lesson is derived from courses originally developed at University of Bristol.
